package com.towerplus.dockerpoc.demo;

import java.util.HashMap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {
	
	public static HashMap<Long,StudentVO> studentHashMap;

	public static void main(String[] args) {
		
		studentHashMap = new HashMap<Long,StudentVO>();
		StudentVO studentVOOne = new StudentVO("Andrew","CSE",123456);
		studentHashMap.put(12345L, studentVOOne);		
		SpringApplication.run(DemoApplication.class, args);
		StudentVO studentVOTwo = new StudentVO("Stephen","EEE",1234);
		studentHashMap.put(12346L, studentVOTwo);		
		
		
	}
}
