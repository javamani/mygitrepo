package com.towerplus.dockerpoc.demo;

import java.util.HashMap;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/rest/Student")
public class StudentService {

	@RequestMapping(value="/",method = RequestMethod.GET)
	public HashMap<Long,StudentVO> getAllStudents() {
		return DemoApplication.studentHashMap;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public StudentVO addStudent(@RequestParam(value="name")String Name,@RequestParam(value="dept")String Dept , @RequestParam(value="rollno")Long rollNumber){
		StudentVO  studentObj = new StudentVO(Name,Dept,rollNumber);
		DemoApplication.studentHashMap.put(5555L, studentObj);
		return studentObj;		
	}
	
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public StudentVO updateStudent(@RequestBody StudentVO student)throws Exception{		
		if(DemoApplication.studentHashMap.containsKey(student.getRollNumber())){
			DemoApplication.studentHashMap.put(student.getRollNumber(),student);
		} else {
			throw new Exception("StudentId :" + student.getRollNumber() + "does not exist");
		}		
		return student;
	}
	
	@RequestMapping(value="/delete/{id}",method = RequestMethod.DELETE)
	public StudentVO deleteStudent(@PathVariable long id) throws Exception {
	   StudentVO student;
	   if(DemoApplication.studentHashMap.containsKey(id)){
	      student=DemoApplication.studentHashMap.get(id);
	      DemoApplication.studentHashMap.remove(new Long(id));
	   }else{
	      throw new Exception("Student "+id+" does not exists");
	   }
	   return student;
	}
	
	
}
