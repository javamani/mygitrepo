package com.towerplus.dockerpoc.demo;

public class StudentVO {
	
	String name;
	String dept;
	long rollNumber;
	
	public StudentVO(){
		
	}
	
	public StudentVO(String name,String dept,long rollNumber){
		this.name = name;
		this.dept = dept;
		this.rollNumber = rollNumber;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public long getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(long rollNumber) {
		this.rollNumber = rollNumber;
	}
	
	@Override
	public String toString(){
		return "Student {"
				+ "name " + name
				+ "Dept " + dept
				+ "RollNumber" + rollNumber 
				+ "}";				
	}
}
